# JIGAR AI — Mobile-installable app package

This package adds your selected JIGAR AI icon and installable PWA support to the web app.

## What you get
- Responsive JIGAR AI website
- Custom JIGAR AI launcher icon
- Android Chrome "Install app" / "Add to Home screen" support
- Service worker for caching the app shell
- FastAPI + OpenAI backend and SQLite starter
- Expo Android source retained in `mobile/`

## Important: what is and isn't automatic
A chat attachment cannot install itself onto your phone or run a server. To install this as an app:
1. Deploy the `web/` frontend to an HTTPS host.
2. Deploy `backend/` to a server that stays online.
3. Set the frontend `VITE_API_BASE_URL` to the deployed backend URL before building.
4. Set `OPENAI_API_KEY` as a secret in the backend host's environment. Never put it in frontend files.
5. Open the HTTPS website in Chrome on Android → menu (⋮) → Install app / Add to Home screen.

The backend starter currently has no user login or user-specific authorization. Do not make it public until authentication, per-user chat isolation, rate limits, usage limits, HTTPS, privacy policy, and monitoring are added.

## Local development
Follow `README.md`. For web development:
```bash
cd web
npm install
npm run dev
```
The web UI expects the FastAPI backend at `http://localhost:8000` by default. For a real phone, local localhost does not refer to your computer; use a deployed HTTPS backend or your computer's LAN IP during testing.

## Android APK
The `mobile/` directory is the Expo Android source. It still requires Expo/EAS build configuration and a backend URL. The PWA path is the easiest way to get an app-like install from an Android phone without compiling an APK locally.

## AI capability
The app uses the OpenAI API for text chat. It is not an exact copy of ChatGPT and does not automatically include every ChatGPT feature. Voice, image input, PDF reading, web search, accounts and memory require additional implementation. API usage is billed separately from a ChatGPT subscription.
