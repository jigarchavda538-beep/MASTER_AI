# JIGAR AI — One complete starter project

This single folder contains:
- `web/`: responsive React website
- `mobile/`: Expo / React Native Android app source
- `backend/`: FastAPI server, OpenAI Responses API integration, SQLite chat storage
- `SETUP-WINDOWS.bat`: one-time setup
- `START-WINDOWS.bat`: starts backend + website

## Important
This is a runnable **local MVP**, not a finished public production service. You must supply your own OpenAI API key and run setup on a computer. I cannot create an API key, pay API bills, publish to Google Play, or host it under your accounts. Never share your API key.

## A. Windows — easiest setup
1. Install Python 3.10+ and Node.js LTS.
2. Extract this ZIP.
3. Double-click `SETUP-WINDOWS.bat` once.
4. Open `backend/.env` and add your API key after `OPENAI_API_KEY=`.
5. Double-click `START-WINDOWS.bat`.
6. Open `http://localhost:5173`.

## B. Manual backend setup
```powershell
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
# Edit .env and add your API key
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```
Health check: http://localhost:8000/health

## C. Manual website setup
In another terminal:
```powershell
cd web
npm install
copy .env.example .env
npm run dev
```
Open http://localhost:5173

## D. Android app
The `mobile/` folder contains the Android app screen. Create a current Expo project:
```bash
npx create-expo-app@latest jigar-ai-mobile
cd jigar-ai-mobile
npx expo install @react-native-async-storage/async-storage
```
Copy `mobile/App.js`, `mobile/app.json`, and `mobile/src/config.js` into that project (create `src/` if needed). Edit `src/config.js`:
- Android emulator: `http://10.0.2.2:8000`
- Physical phone: `http://YOUR_PC_WIFI_IP:8000`
Keep phone and PC on the same Wi-Fi. Find the PC IPv4 address with `ipconfig`. Then run:
```bash
npx expo start
```
Install Expo Go on Android and scan the QR code.

## E. Android APK/AAB build
```bash
npm install -g eas-cli
cd jigar-ai-mobile
eas build:configure
eas build --platform android
```
An Expo/EAS account and build configuration are required. Follow current prompts to choose APK for testing or AAB for Play Store.

## API configuration
`backend/.env`:
```env
OPENAI_API_KEY=your_secret_key_here
OPENAI_MODEL=gpt-4.1-mini
DATABASE_PATH=./jigar_ai.db
```
Model access and API pricing can change. Check your API account's model access and billing. ChatGPT subscriptions and API billing are separate.

## Included in this MVP
- Text chat powered by OpenAI
- Hindi, Gujarati and English response instructions
- Recent conversation context
- SQLite conversation persistence
- Responsive web interface
- Expo Android client

Not included yet: accounts/login, authenticated per-user chat isolation, voice, image upload, PDF parsing, web search, subscriptions, admin panel, public hosting, or Play Store release.

## Before public launch
Do not deploy this starter publicly as-is. Add authentication and per-user authorization, rate limits, abuse prevention, HTTPS, backups, privacy policy, terms, monitoring and a managed database. Restrict CORS to your deployed website domain. This MVP has no login and conversation IDs are not user-authenticated.
