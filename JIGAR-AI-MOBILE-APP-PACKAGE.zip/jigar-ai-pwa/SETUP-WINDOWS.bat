@echo off
setlocal
cd /d "%~dp0"
echo ===== JIGAR AI FIRST-TIME SETUP =====
where python >nul 2>nul || (echo Install Python 3.10+ first. & pause & exit /b 1)
where node >nul 2>nul || (echo Install Node.js LTS first. & pause & exit /b 1)
if not exist "backend\.venv" python -m venv backend\.venv
call backend\.venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r backend\requirements.txt || (echo Backend install failed. & pause & exit /b 1)
if not exist "backend\.env" copy "backend\.env.example" "backend\.env" >nul
if not exist "web\.env" copy "web\.env.example" "web\.env" >nul
cd web
call npm install
if errorlevel 1 (echo Website install failed. & pause & exit /b 1)
cd ..
echo.
echo Setup complete. Add your OpenAI API key in backend\.env
echo Then double-click START-WINDOWS.bat
pause
