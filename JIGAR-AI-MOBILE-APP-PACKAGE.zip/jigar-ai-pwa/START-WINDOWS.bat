@echo off
setlocal
cd /d "%~dp0"
if not exist "backend\.venv\Scripts\python.exe" (echo Run SETUP-WINDOWS.bat first. & pause & exit /b 1)
if not exist "backend\.env" (echo Missing backend\.env. Run setup first. & pause & exit /b 1)
start "JIGAR AI Backend" cmd /k "cd /d ""%~dp0backend"" && .venv\Scripts\activate && uvicorn app:app --reload --host 0.0.0.0 --port 8000"
timeout /t 3 /nobreak >nul
start "JIGAR AI Website" cmd /k "cd /d ""%~dp0web"" && npm run dev -- --host 0.0.0.0"
timeout /t 3 /nobreak >nul
start "" "http://localhost:5173"
echo JIGAR AI started. Keep both terminal windows open.
