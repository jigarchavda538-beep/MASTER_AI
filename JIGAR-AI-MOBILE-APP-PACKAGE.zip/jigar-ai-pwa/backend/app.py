import json
import os
import sqlite3
import uuid
from pathlib import Path
from typing import Literal

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI
from pydantic import BaseModel, Field

load_dotenv()

APP_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("DATABASE_PATH", str(APP_DIR / "jigar_ai.db")))
MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
SYSTEM_INSTRUCTIONS = (
    "You are JIGAR AI, a helpful, accurate, friendly assistant. "
    "Reply in the language the user uses (Gujarati, Hindi, or English). "
    "Explain clearly and structure longer answers with headings and examples. "
    "If you are unsure, say so rather than inventing facts."
)

app = FastAPI(title="JIGAR AI API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict to your deployed website origin before production.
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)


def db_connect():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS conversations ("
        "id TEXT PRIMARY KEY, messages TEXT NOT NULL, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)"
    )
    return conn


class ChatRequest(BaseModel):
    conversation_id: str | None = None
    message: str = Field(min_length=1, max_length=12000)


class ChatResponse(BaseModel):
    conversation_id: str
    reply: str


@app.get("/health")
def health():
    return {"status": "ok", "app": "JIGAR AI"}


@app.post("/api/chat", response_model=ChatResponse)
def chat(payload: ChatRequest):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key or api_key == "put_your_secret_key_here":
        raise HTTPException(status_code=503, detail="Server API key is not configured. Add OPENAI_API_KEY to backend/.env.")

    conversation_id = payload.conversation_id or str(uuid.uuid4())
    conn = db_connect()
    try:
        row = conn.execute("SELECT messages FROM conversations WHERE id = ?", (conversation_id,)).fetchone()
        history = json.loads(row[0]) if row else []
        history = history[-20:]  # Keep a bounded recent context for this starter.
        history.append({"role": "user", "content": payload.message})

        client = OpenAI(api_key=api_key)
        response = client.responses.create(
            model=MODEL,
            instructions=SYSTEM_INSTRUCTIONS,
            input=history,
        )
        reply = (response.output_text or "I couldn't create a response. Please try again.").strip()
        history.append({"role": "assistant", "content": reply})
        conn.execute(
            "INSERT INTO conversations (id, messages) VALUES (?, ?) "
            "ON CONFLICT(id) DO UPDATE SET messages=excluded.messages, updated_at=CURRENT_TIMESTAMP",
            (conversation_id, json.dumps(history, ensure_ascii=False)),
        )
        conn.commit()
        return ChatResponse(conversation_id=conversation_id, reply=reply)
    except HTTPException:
        raise
    except Exception as exc:
        # Avoid returning internal credentials or stack traces to clients.
        raise HTTPException(status_code=502, detail=f"AI request failed: {type(exc).__name__}. Check server logs.")
    finally:
        conn.close()
