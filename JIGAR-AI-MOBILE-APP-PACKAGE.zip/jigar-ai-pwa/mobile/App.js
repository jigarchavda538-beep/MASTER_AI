import React, { useEffect, useRef, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList, KeyboardAvoidingView, Platform, StyleSheet, ActivityIndicator, StatusBar } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_BASE_URL } from './src/config';

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [conversationId, setConversationId] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const listRef = useRef(null);

  useEffect(() => { (async () => {
    const savedId = await AsyncStorage.getItem('jigar_ai_conversation');
    if (savedId) setConversationId(savedId);
  })(); }, []);

  async function send(text = input) {
    const value = text.trim();
    if (!value || busy) return;
    setInput(''); setError(''); setMessages(prev => [...prev, { id: `${Date.now()}-u`, role: 'user', content: value }]); setBusy(true);
    try {
      const response = await fetch(`${API_BASE_URL}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ conversation_id: conversationId, message: value }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Request failed');
      setConversationId(data.conversation_id); await AsyncStorage.setItem('jigar_ai_conversation', data.conversation_id);
      setMessages(prev => [...prev, { id: `${Date.now()}-a`, role: 'assistant', content: data.reply }]);
    } catch (e) { setError(e.message || 'Could not connect.'); }
    finally { setBusy(false); }
  }

  function newChat() { setMessages([]); setConversationId(null); setError(''); AsyncStorage.removeItem('jigar_ai_conversation'); }

  return <SafeAreaView style={styles.safe}><StatusBar barStyle="dark-content" backgroundColor="#f5f9ff"/><KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    <View style={styles.header}><View style={styles.logo}><Text style={styles.logoText}>✦</Text></View><View style={{flex:1}}><Text style={styles.title}>JIGAR AI</Text><Text style={styles.subtitle}>Your personal AI assistant</Text></View><TouchableOpacity onPress={newChat} style={styles.newButton}><Text style={styles.newButtonText}>＋</Text></TouchableOpacity></View>
    {messages.length === 0 ? <View style={styles.welcome}><View style={styles.hero}><Text style={styles.heroIcon}>✧</Text></View><Text style={styles.eyebrow}>YOUR PERSONAL AI ASSISTANT</Text><Text style={styles.heading}>What can I help<Text style={styles.blue}> you with today?</Text></Text><Text style={styles.description}>Ask anything. Learn, create and explore with JIGAR AI.</Text><View style={styles.quickList}>{['Explain a topic simply','Help me write some code','Make a study plan'].map(t => <TouchableOpacity key={t} style={styles.quick} onPress={() => send(t)}><Text style={styles.quickText}>{t}</Text><Text style={styles.quickArrow}>›</Text></TouchableOpacity>)}</View></View> : <FlatList ref={listRef} style={styles.list} contentContainerStyle={{paddingVertical:18}} data={messages} keyExtractor={item => item.id} onContentSizeChange={() => listRef.current?.scrollToEnd({animated:true})} renderItem={({item}) => <View style={[styles.bubble, item.role === 'user' ? styles.userBubble : styles.aiBubble]}><Text style={styles.role}>{item.role === 'user' ? 'YOU' : 'JIGAR AI'}</Text><Text style={styles.message}>{item.content}</Text></View>}/>}
    {busy && <View style={styles.loading}><ActivityIndicator color="#1769d2"/><Text style={styles.loadingText}>JIGAR AI is thinking...</Text></View>}
    {!!error && <Text style={styles.error}>{error}</Text>}
    <View style={styles.composer}><TextInput value={input} onChangeText={setInput} placeholder="Message JIGAR AI..." placeholderTextColor="#94a7bd" multiline style={styles.input}/><TouchableOpacity onPress={() => send()} disabled={!input.trim() || busy} style={[styles.send, (!input.trim() || busy) && {opacity:.4}]}><Text style={styles.sendText}>➤</Text></TouchableOpacity></View>
    <Text style={styles.foot}>AI can make mistakes. Check important information.</Text>
  </KeyboardAvoidingView></SafeAreaView>;
}

const styles = StyleSheet.create({safe:{flex:1,backgroundColor:'#f5f9ff'},container:{flex:1},header:{height:68,backgroundColor:'#fff',borderBottomWidth:1,borderBottomColor:'#e6eef8',flexDirection:'row',alignItems:'center',paddingHorizontal:17,gap:11},logo:{width:40,height:40,borderRadius:13,backgroundColor:'#1769d2',alignItems:'center',justifyContent:'center'},logoText:{color:'#fff',fontSize:23},title:{fontSize:15,fontWeight:'800',color:'#17385f',letterSpacing:.5},subtitle:{fontSize:10,color:'#8a9cb2',marginTop:3},newButton:{width:37,height:37,borderRadius:11,backgroundColor:'#edf5ff',alignItems:'center',justifyContent:'center'},newButtonText:{fontSize:23,color:'#1769d2'},welcome:{flex:1,alignItems:'center',justifyContent:'center',paddingHorizontal:24},hero:{width:65,height:65,borderRadius:22,backgroundColor:'#1769d2',alignItems:'center',justifyContent:'center',marginBottom:20},heroIcon:{fontSize:34,color:'#fff'},eyebrow:{fontSize:9,fontWeight:'800',letterSpacing:1.8,color:'#7194bf'},heading:{fontSize:31,lineHeight:38,fontWeight:'800',color:'#17385f',textAlign:'center',marginTop:13},blue:{color:'#287bdc'},description:{fontSize:13,lineHeight:20,color:'#8193a9',textAlign:'center',marginTop:10},quickList:{width:'100%',marginTop:28,gap:9},quick:{backgroundColor:'#fff',borderColor:'#e4edf8',borderWidth:1,borderRadius:13,padding:15,flexDirection:'row',justifyContent:'space-between'},quickText:{fontSize:12,fontWeight:'600',color:'#345575'},quickArrow:{fontSize:19,color:'#4386d5',marginTop:-4},list:{flex:1,paddingHorizontal:15},bubble:{padding:14,borderRadius:15,marginBottom:12,maxWidth:'94%'},userBubble:{alignSelf:'flex-end',backgroundColor:'#e3efff'},aiBubble:{alignSelf:'flex-start',backgroundColor:'#fff',borderWidth:1,borderColor:'#e5edf7'},role:{fontSize:9,fontWeight:'800',letterSpacing:1,color:'#4c7db7',marginBottom:7},message:{fontSize:14,lineHeight:21,color:'#2e4865'},loading:{flexDirection:'row',alignItems:'center',gap:9,paddingHorizontal:18,paddingVertical:8},loadingText:{fontSize:11,color:'#7690ad'},error:{color:'#c43b3b',fontSize:11,paddingHorizontal:17,paddingBottom:5},composer:{marginHorizontal:13,marginTop:5,backgroundColor:'#fff',borderWidth:1,borderColor:'#dce8f6',borderRadius:16,padding:9,flexDirection:'row',alignItems:'flex-end',gap:8},input:{flex:1,minHeight:39,maxHeight:110,paddingHorizontal:7,paddingVertical:8,fontSize:14,color:'#213d5d'},send:{width:39,height:39,borderRadius:12,backgroundColor:'#1769d2',alignItems:'center',justifyContent:'center'},sendText:{color:'#fff',fontSize:19},foot:{textAlign:'center',fontSize:9,color:'#9aaabd',paddingTop:9,paddingBottom:10}});
