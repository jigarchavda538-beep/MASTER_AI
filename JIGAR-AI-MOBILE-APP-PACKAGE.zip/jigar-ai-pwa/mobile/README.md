# Android app source

This folder contains `App.js`, `app.json`, and `src/config.js` for the Expo Android app.

For the current Expo SDK compatible with your installed Expo Go, create a fresh project and copy these files into it:

```bash
npx create-expo-app@latest jigar-ai-mobile
cd jigar-ai-mobile
npx expo install @react-native-async-storage/async-storage
```

Copy this folder's `App.js`, `app.json`, and `src/config.js` into the new project (replace the generated files where names match), then set `API_BASE_URL` in `src/config.js` to your computer's LAN IP, for example `http://192.168.1.10:8000`.

Run `npx expo start`, then scan the QR code using Expo Go. Keep the phone and computer on the same Wi-Fi network.
