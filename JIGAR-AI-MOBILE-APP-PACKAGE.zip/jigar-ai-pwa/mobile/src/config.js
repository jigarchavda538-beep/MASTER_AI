// Android emulator: http://10.0.2.2:8000
// Physical phone: use your computer's LAN IP, e.g. http://192.168.1.10:8000
export const API_BASE_URL = 'http://10.0.2.2:8000';
