import { useEffect, useRef, useState } from 'react';
import { Bot, Plus, Send, Sparkles, Menu, MessageCircle } from 'lucide-react';

const API = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';
const starter = [
  { icon: '✦', title: 'Learn something', prompt: 'Explain a difficult topic in simple words.' },
  { icon: '⌘', title: 'Write code', prompt: 'Help me write a simple Python program.' },
  { icon: '▤', title: 'Study smarter', prompt: 'Make a short study plan for my exams.' },
  { icon: '◉', title: 'Explore ideas', prompt: 'Give me creative ideas for a useful student project.' },
];

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [conversationId, setConversationId] = useState(() => localStorage.getItem('jigar_ai_conversation') || null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), [messages, busy]);

  function newChat() {
    setMessages([]); setConversationId(null); setInput(''); setError('');
    localStorage.removeItem('jigar_ai_conversation'); setSidebarOpen(false);
  }

  async function send(text = input) {
    const value = text.trim();
    if (!value || busy) return;
    setError(''); setInput('');
    setMessages(prev => [...prev, { role: 'user', content: value }]);
    setBusy(true);
    try {
      const res = await fetch(`${API}/api/chat`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conversation_id: conversationId, message: value }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Could not reach JIGAR AI.');
      setConversationId(data.conversation_id);
      localStorage.setItem('jigar_ai_conversation', data.conversation_id);
      setMessages(prev => [...prev, { role: 'assistant', content: data.reply }]);
    } catch (e) {
      setError(e.message || 'Something went wrong.');
      setMessages(prev => [...prev, { role: 'assistant', content: 'I could not connect just now. Please check that the JIGAR AI backend is running and try again.' }]);
    } finally { setBusy(false); }
  }

  return <div className="app-shell">
    <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
      <div className="brand"><div className="brand-icon"><img src="/jigar-icon-192.png" alt="JIGAR AI" /></div><div><b>JIGAR AI</b><small>Your AI assistant</small></div></div>
      <button className="new-chat" onClick={newChat}><Plus size={17}/> New chat</button>
      <div className="side-label">WORKSPACE</div>
      <div className="side-item active"><MessageCircle size={17}/> Chat</div>
      <div className="side-bottom"><div className="avatar">J</div><div><b>JIGAR AI</b><small>Personal assistant</small></div></div>
    </aside>

    <main className="main-area">
      <header className="topbar"><button className="icon-btn mobile-menu" onClick={() => setSidebarOpen(!sidebarOpen)}><Menu size={20}/></button><div className="status"><span className="online-dot"/> AI assistant <span className="model-tag">OpenAI</span></div><button className="icon-btn" title="New chat" onClick={newChat}><Plus size={19}/></button></header>
      <section className="chat-area">
        {messages.length === 0 ? <div className="welcome">
          <div className="welcome-orb"><img src="/jigar-icon-192.png" alt="JIGAR AI" /></div>
          <div className="eyebrow">YOUR PERSONAL AI ASSISTANT</div>
          <h1>What can I help<br/><span>you with today?</span></h1>
          <p>Ask anything. Learn, create, solve problems and explore new ideas with JIGAR AI.</p>
          <div className="suggestions">{starter.map(item => <button className="suggestion" key={item.title} onClick={() => send(item.prompt)}><span>{item.icon}</span><b>{item.title}</b><small>{item.prompt}</small></button>)}</div>
        </div> : <div className="messages">{messages.map((m, i) => <div className={`message-row ${m.role}`} key={i}><div className="message-avatar">{m.role === 'assistant' ? <Bot size={18}/> : 'J'}</div><div className="message-content"><div className="message-name">{m.role === 'assistant' ? 'JIGAR AI' : 'You'}</div><div className="message-text">{m.content}</div></div></div>)}{busy && <div className="message-row assistant"><div className="message-avatar"><Bot size={18}/></div><div className="message-content"><div className="message-name">JIGAR AI</div><div className="typing"><i/><i/><i/></div></div></div>}<div ref={bottomRef}/></div>}
      </section>
      <div className="composer-wrap"><form className="composer" onSubmit={e => { e.preventDefault(); send(); }}><textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} placeholder="Message JIGAR AI..." rows={1}/><button className="send-btn" disabled={!input.trim() || busy} aria-label="Send message"><Send size={18}/></button></form>{error && <div className="error-text">{error}</div>}<div className="disclaimer">JIGAR AI can make mistakes. Check important information.</div></div>
    </main>
  </div>;
}
