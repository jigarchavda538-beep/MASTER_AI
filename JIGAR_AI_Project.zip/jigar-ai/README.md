# JIGAR AI

Futuristic dark AI assistant starter: React website + Expo Android app + FastAPI backend + OpenAI Responses API.

## Included in v1
- Shared FastAPI backend for web and Android
- OpenAI Responses API integration
- Hindi, Gujarati and English-friendly assistant instructions
- Conversation history stored locally in each client
- Dark responsive UI
- Backend-only API key (never put it in web/mobile source)

## Requirements
- Python 3.10+
- Node.js LTS + npm
- OpenAI API key with API billing/credits configured
- Android: Expo Go for testing, or EAS Build for an installable APK/AAB

## 1. Backend setup

Open a terminal in `backend/`:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

Copy `.env.example` to `.env`, then set your key:

```env
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-5.5
ALLOWED_ORIGINS=http://localhost:5173
```

Start the API:

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Check `http://127.0.0.1:8000/health` and API docs at `http://127.0.0.1:8000/docs`.

If your API account does not have access to the configured model, change `OPENAI_MODEL` to a model available in your account.

## 2. Website setup

In a second terminal:

```bash
cd web
npm install
```

Create `web/.env`:

```env
VITE_API_URL=http://localhost:8000
```

Start:

```bash
npm run dev
```

Open `http://localhost:5173`.

## 3. Android setup

In a third terminal:

```bash
cd mobile
npm install
```

Set the API URL in `mobile/.env`:

```env
# Android emulator:
EXPO_PUBLIC_API_URL=http://10.0.2.2:8000

# For a physical Android phone on the same Wi-Fi, use your computer's LAN IP:
# EXPO_PUBLIC_API_URL=http://192.168.1.10:8000
```

Start Expo:

```bash
npx expo start
```

Install Expo Go on the Android phone and scan the QR code. The phone and computer should be on the same Wi-Fi. Allow port 8000 through your computer firewall if needed.

## 4. Build an Android installable app

For a store-ready or installable Android build, use Expo Application Services (EAS). From `mobile/`:

```bash
npx eas-cli login
npx eas-cli build:configure
npx eas-cli build --platform android --profile preview
```

The EAS build process will provide the build artifact when complete. Follow the current Expo EAS documentation for account setup and Android signing.

## Project structure

```text
jigar-ai/
  backend/
    main.py
    requirements.txt
    .env.example
  web/
    index.html
    package.json
    vite.config.js
    .env.example
    src/
      main.jsx
      App.jsx
      style.css
  mobile/
    App.js
    app.json
    package.json
    .env.example
```

## Important production checklist
This is a functional development starter, not yet a public multi-user production service.
Before publishing:
- Add user authentication and per-user server-side conversation storage.
- Add server-side rate limiting, quotas, abuse monitoring and spending limits.
- Restrict CORS to your real website domain.
- Use HTTPS for the deployed API.
- Add privacy notice, data retention controls and account deletion.
- Never commit `.env` files or share API keys. If a key is exposed, revoke it and create a new one.
- Do not expose the backend directly to the public without authentication and rate limits.

Chat history in this starter is stored locally in the browser or on the phone, not in a cloud account.
