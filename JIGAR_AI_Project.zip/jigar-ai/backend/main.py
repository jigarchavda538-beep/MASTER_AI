import os
from typing import Literal
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI, APIError, AuthenticationError, RateLimitError
from pydantic import BaseModel, Field

load_dotenv()

API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.5").strip()

app = FastAPI(title="JIGAR AI API", version="1.0.0")

origins = [
    item.strip()
    for item in os.getenv("ALLOWED_ORIGINS", "http://localhost:5173").split(",")
    if item.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=12000)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    history: list[ChatMessage] = Field(default_factory=list, max_length=30)

class ChatResponse(BaseModel):
    reply: str
    model: str

@app.get("/")
def root():
    return {"name": "JIGAR AI API", "status": "running"}

@app.get("/health")
def health():
    return {"ok": True, "model": MODEL, "api_key_configured": bool(API_KEY)}

@app.post("/api/chat", response_model=ChatResponse)
def chat(body: ChatRequest):
    if not API_KEY:
        raise HTTPException(
            status_code=503,
            detail="Server API key is not configured. Add OPENAI_API_KEY to backend/.env."
        )

    # Only recent turns are sent, limiting accidental oversized requests.
    history = body.history[-20:]
    conversation = [
        {"role": item.role, "content": item.content}
        for item in history
    ]
    conversation.append({"role": "user", "content": body.message})

    try:
        client = OpenAI(api_key=API_KEY, timeout=60.0)
        result = client.responses.create(
            model=MODEL,
            instructions=(
                "You are JIGAR AI, a helpful, accurate and friendly AI assistant. "
                "Reply in the language used by the user (Hindi, Gujarati, English, "
                "or a natural mix). Explain clearly and structure longer answers. "
                "If you are unsure, say so instead of inventing facts."
            ),
            input=conversation,
        )
        reply = (result.output_text or "").strip()
        if not reply:
            reply = "I couldn't generate a text response. Please try again."
        return ChatResponse(reply=reply, model=MODEL)

    except AuthenticationError:
        raise HTTPException(status_code=502, detail="OpenAI authentication failed. Check the server API key.")
    except RateLimitError:
        raise HTTPException(status_code=429, detail="AI usage limit reached. Please try again later.")
    except APIError as exc:
        raise HTTPException(status_code=502, detail=f"AI provider error: {str(exc)[:300]}")
    except Exception:
        raise HTTPException(status_code=500, detail="Unexpected server error. Check backend logs.")
