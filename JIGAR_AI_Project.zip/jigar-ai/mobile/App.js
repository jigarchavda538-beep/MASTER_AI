import React, { useEffect, useRef, useState } from 'react'
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList, KeyboardAvoidingView, Platform, ActivityIndicator, StatusBar } from 'react-native'
import AsyncStorage from '@react-native-async-storage/async-storage'
import { Bot, Plus, Send, Sparkles, MessageSquare, Trash2 } from 'lucide-react-native'

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://10.0.2.2:8000'
const STORE = 'jigar-ai-mobile-chats-v1'
const suggestions = [
  'Explain AI in simple words',
  'Help me learn Python',
  'ગુજરાતીમાં સમજાવો',
  'Create a study timetable'
]

export default function App() {
  const [chats, setChats] = useState([])
  const [activeId, setActiveId] = useState(null)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const listRef = useRef(null)
  const active = chats.find(c => c.id === activeId)
  const messages = active?.messages || []

  useEffect(() => { AsyncStorage.getItem(STORE).then(v => { if (v) { const parsed = JSON.parse(v); setChats(parsed); if (parsed[0]) setActiveId(parsed[0].id) } }).catch(() => {}) }, [])
  useEffect(() => { AsyncStorage.setItem(STORE, JSON.stringify(chats)).catch(() => {}) }, [chats])

  function newChat() { setActiveId(null); setInput('') }
  function replaceMessages(id, next) {
    setChats(prev => prev.map(c => c.id === id ? { ...c, messages: next } : c))
  }

  async function send(text = input) {
    const content = text.trim()
    if (!content || loading) return
    const id = activeId || `${Date.now()}-${Math.random().toString(16).slice(2)}`
    const existing = chats.find(c => c.id === id)
    const prior = existing?.messages || []
    const pending = [...prior, { role: 'user', content }]
    if (!existing) {
      setChats(prev => [{ id, title: content.slice(0, 38), messages: pending }, ...prev])
      setActiveId(id)
    } else replaceMessages(id, pending)
    setInput('')
    setLoading(true)
    try {
      const res = await fetch(`${API_URL}/api/chat`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: content, history: prior })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Request failed')
      replaceMessages(id, [...pending, { role: 'assistant', content: data.reply }])
    } catch (e) {
      replaceMessages(id, [...pending, { role: 'assistant', content: `Error: ${e.message}. Check backend URL and server.` }])
    } finally { setLoading(false) }
  }

  function deleteActive() {
    setChats(prev => prev.filter(c => c.id !== activeId))
    setActiveId(null)
  }

  const Bubble = ({ item }) => (
    <View style={[styles.bubbleRow, item.role === 'user' && styles.userRow]}>
      <View style={[styles.avatar, item.role === 'user' && styles.userAvatar]}>{item.role === 'assistant' ? <Bot color="#8ccaff" size={18}/> : <Text style={{color:'#fff',fontWeight:'800'}}>J</Text>}</View>
      <View style={styles.bubbleContent}>
        <Text style={styles.role}>{item.role === 'assistant' ? 'JIGAR AI' : 'YOU'}</Text>
        <Text style={styles.message}>{item.content}</Text>
      </View>
    </View>
  )

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#070b14"/>
      <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.header}>
          <View style={styles.brandIcon}><Bot color="#d8edff" size={22}/></View>
          <View style={{flex:1}}><Text style={styles.brand}>JIGAR <Text style={{color:'#61b5ff'}}>AI</Text></Text><Text style={styles.subtitle}>YOUR INTELLIGENT COMPANION</Text></View>
          <TouchableOpacity style={styles.headerBtn} onPress={newChat}><Plus color="#b7d8ff" size={21}/></TouchableOpacity>
          <TouchableOpacity style={styles.headerBtn} onPress={deleteActive}><Trash2 color="#8299b8" size={18}/></TouchableOpacity>
        </View>

        {messages.length === 0 ? (
          <View style={styles.welcome}>
            <View style={styles.orb}><Sparkles color="#d9f0ff" size={34}/></View>
            <Text style={styles.eyebrow}>SYSTEM ONLINE</Text>
            <Text style={styles.title}>Think beyond.{"\n"}<Text style={{color:'#72baff'}}>Ask JIGAR AI.</Text></Text>
            <Text style={styles.desc}>Explore ideas, solve problems and create something extraordinary.</Text>
            <View style={styles.suggestions}>
              {suggestions.map(s => <TouchableOpacity key={s} style={styles.suggestion} onPress={() => send(s)}><Text style={styles.suggestionText}>{s}</Text></TouchableOpacity>)}
            </View>
          </View>
        ) : (
          <FlatList ref={listRef} data={messages} keyExtractor={(_,i)=>String(i)} renderItem={({item})=><Bubble item={item}/>} contentContainerStyle={styles.messageList} onContentSizeChange={()=>listRef.current?.scrollToEnd({animated:true})} />
        )}

        {loading && <View style={styles.loading}><ActivityIndicator color="#65b7ff"/><Text style={styles.loadingText}>JIGAR AI is thinking...</Text></View>}
        <View style={styles.composer}>
          <TextInput value={input} onChangeText={setInput} placeholder="Message JIGAR AI..." placeholderTextColor="#7085a2" multiline style={styles.input} onSubmitEditing={()=>send()} returnKeyType="send"/>
          <TouchableOpacity disabled={!input.trim() || loading} onPress={()=>send()} style={[styles.sendBtn, (!input.trim() || loading) && {opacity:.4}]}><Send color="#fff" size={18}/></TouchableOpacity>
        </View>
        <Text style={styles.disclaimer}>JIGAR AI can make mistakes. Verify important information.</Text>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = {
  safe:{flex:1,backgroundColor:'#070b14'},
  container:{flex:1,backgroundColor:'#070b14'},
  header:{height:68,paddingHorizontal:17,borderBottomWidth:1,borderBottomColor:'#1b2b43',flexDirection:'row',alignItems:'center',gap:11},
  brandIcon:{width:40,height:40,borderRadius:13,backgroundColor:'#174d87',alignItems:'center',justifyContent:'center'},
  brand:{color:'#eff7ff',fontSize:17,fontWeight:'900',letterSpacing:1.1},
  subtitle:{color:'#7188a7',fontSize:8,letterSpacing:1.1,marginTop:3},
  headerBtn:{width:37,height:37,borderRadius:11,borderWidth:1,borderColor:'#253d5d',alignItems:'center',justifyContent:'center'},
  welcome:{flex:1,alignItems:'center',justifyContent:'center',paddingHorizontal:22},
  orb:{width:90,height:90,borderRadius:45,backgroundColor:'#153d70',borderWidth:1,borderColor:'#398bd0',alignItems:'center',justifyContent:'center',marginBottom:24,shadowColor:'#248fff',shadowOpacity:.5,shadowRadius:22,elevation:10},
  eyebrow:{color:'#7da8d8',fontSize:10,letterSpacing:2,fontWeight:'700'},
  title:{color:'#f1f7ff',fontSize:34,fontWeight:'900',textAlign:'center',lineHeight:42,marginTop:13,letterSpacing:-1},
  desc:{color:'#8da3c1',fontSize:13,lineHeight:21,textAlign:'center',marginTop:13,maxWidth:310},
  suggestions:{width:'100%',gap:9,marginTop:27},
  suggestion:{padding:14,borderRadius:12,borderWidth:1,borderColor:'#263d5b',backgroundColor:'#101d30'},
  suggestionText:{color:'#c8ddf7',fontSize:12,fontWeight:'600'},
  messageList:{padding:17,paddingBottom:25,gap:23},
  bubbleRow:{flexDirection:'row',gap:10,alignItems:'flex-start'},
  userRow:{},
  avatar:{width:34,height:34,borderRadius:11,backgroundColor:'#15304f',borderWidth:1,borderColor:'#2d527c',alignItems:'center',justifyContent:'center'},
  userAvatar:{backgroundColor:'#244d80'},
  bubbleContent:{flex:1},
  role:{color:'#82b8eb',fontSize:9,fontWeight:'800',letterSpacing:1.2,marginBottom:7},
  message:{color:'#dbe8f8',fontSize:14,lineHeight:22},
  loading:{flexDirection:'row',alignItems:'center',gap:9,paddingHorizontal:18,paddingBottom:8},
  loadingText:{color:'#8da7c8',fontSize:11},
  composer:{marginHorizontal:12,marginTop:5,padding:10,borderRadius:15,borderWidth:1,borderColor:'#2b4b70',backgroundColor:'#101d30',flexDirection:'row',alignItems:'flex-end',gap:8},
  input:{flex:1,color:'#eef6ff',fontSize:14,maxHeight:110,minHeight:38,paddingHorizontal:5,paddingTop:9},
  sendBtn:{width:38,height:38,borderRadius:11,backgroundColor:'#267fe0',alignItems:'center',justifyContent:'center'},
  disclaimer:{textAlign:'center',color:'#637a99',fontSize:9,marginVertical:9}
}
