import { useEffect, useRef, useState } from 'react'
import { Bot, Plus, Send, Sparkles, MessageSquare, Trash2, Menu, X, Zap, Github } from 'lucide-react'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const STORAGE_KEY = 'jigar-ai-chats-v1'

const starterPrompts = [
  { icon: '✦', title: 'Explain a concept', text: 'Explain artificial intelligence in simple words.' },
  { icon: '⌘', title: 'Write some code', text: 'Create a simple HTML and CSS landing page.' },
  { icon: '◈', title: 'Help me study', text: 'Make a study plan for learning programming.' },
  { icon: '文', title: 'Speak my language', text: 'ગુજરાતીમાં મને AI વિશે સમજાવો.' },
]

function readChats() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]') } catch { return [] }
}

export default function App() {
  const [chats, setChats] = useState(readChats)
  const [activeId, setActiveId] = useState(() => readChats()[0]?.id || null)
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const endRef = useRef(null)

  const activeChat = chats.find(c => c.id === activeId) || null
  const messages = activeChat?.messages || []

  useEffect(() => localStorage.setItem(STORAGE_KEY, JSON.stringify(chats)), [chats])
  useEffect(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), [messages, loading])

  function newChat() {
    setActiveId(null)
    setInput('')
    setSidebarOpen(false)
  }

  function updateMessages(id, nextMessages) {
    setChats(prev => prev.map(c => c.id === id ? { ...c, messages: nextMessages, updatedAt: Date.now() } : c))
  }

  async function sendMessage(text = input) {
    const clean = text.trim()
    if (!clean || loading) return
    const id = activeId || crypto.randomUUID()
    const existing = chats.find(c => c.id === id)
    const prior = existing?.messages || []
    const userMessage = { role: 'user', content: clean }
    const pending = [...prior, userMessage]
    const title = existing?.title || clean.slice(0, 42)
    if (!existing) {
      setChats(prev => [{ id, title, messages: pending, updatedAt: Date.now() }, ...prev])
      setActiveId(id)
    } else updateMessages(id, pending)
    setInput('')
    setLoading(true)
    try {
      const response = await fetch(`${API_URL}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: clean, history: prior })
      })
      const data = await response.json()
      if (!response.ok) throw new Error(data.detail || 'Request failed')
      updateMessages(id, [...pending, { role: 'assistant', content: data.reply }])
    } catch (err) {
      updateMessages(id, [...pending, { role: 'assistant', content: `⚠️ ${err.message}. Check that the JIGAR AI backend is running.` }])
    } finally {
      setLoading(false)
    }
  }

  function deleteChat(id) {
    setChats(prev => prev.filter(c => c.id !== id))
    if (activeId === id) setActiveId(null)
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? 'sidebar-open' : ''}`}>
        <div className="brand">
          <div className="brand-mark"><Bot size={22}/></div>
          <div><strong>JIGAR <span>AI</span></strong><small>INTELLIGENCE, REIMAGINED</small></div>
          <button className="icon-btn close-sidebar" onClick={() => setSidebarOpen(false)}><X size={18}/></button>
        </div>
        <button className="new-chat" onClick={newChat}><Plus size={18}/> New conversation</button>
        <div className="side-label">YOUR WORKSPACE</div>
        <div className="chat-list">
          {chats.map(chat => (
            <div key={chat.id} className={`chat-item ${activeId === chat.id ? 'selected' : ''}`}>
              <button onClick={() => { setActiveId(chat.id); setSidebarOpen(false) }}>
                <MessageSquare size={16}/><span>{chat.title}</span>
              </button>
              <button className="delete-btn" aria-label="Delete conversation" onClick={() => deleteChat(chat.id)}><Trash2 size={14}/></button>
            </div>
          ))}
          {!chats.length && <p className="empty-history">Your conversations will appear here.</p>}
        </div>
        <div className="sidebar-bottom">
          <div className="profile-avatar">J</div>
          <div className="profile-text"><strong>JIGAR AI</strong><small>Personal assistant</small></div>
          <span className="online-dot"/>
        </div>
      </aside>

      {sidebarOpen && <button className="scrim" onClick={() => setSidebarOpen(false)} aria-label="Close menu"/>}

      <main className="main-panel">
        <header className="topbar">
          <div className="top-left">
            <button className="icon-btn mobile-menu" onClick={() => setSidebarOpen(true)}><Menu size={20}/></button>
            <div className="status-pill"><span/> SYSTEM ONLINE</div>
          </div>
          <div className="top-right"><span className="model-label">JIGAR CORE</span><div className="top-orb"><Sparkles size={15}/></div></div>
        </header>

        <section className={`conversation ${messages.length ? 'has-messages' : 'welcome'}`}>
          {!messages.length ? (
            <div className="welcome-content">
              <div className="hero-orb"><div className="orb-core"><Bot size={38}/></div><i/><b/><em/></div>
              <div className="eyebrow"><span/> YOUR INTELLIGENT COMPANION</div>
              <h1>Think beyond.<br/><span>Ask JIGAR AI.</span></h1>
              <p className="hero-copy">A new way to explore ideas, solve problems and create something extraordinary.</p>
              <div className="prompt-grid">
                {starterPrompts.map(p => <button className="prompt-card" key={p.title} onClick={() => sendMessage(p.text)}>
                  <span className="prompt-icon">{p.icon}</span><strong>{p.title}</strong><small>{p.text}</small>
                </button>)}
              </div>
            </div>
          ) : (
            <div className="messages">
              {messages.map((m, i) => <div className={`message-row ${m.role}`} key={i}>
                <div className="message-avatar">{m.role === 'assistant' ? <Bot size={18}/> : 'J'}</div>
                <div className="message-body"><div className="message-name">{m.role === 'assistant' ? 'JIGAR AI' : 'YOU'}</div><div className="message-text">{m.content}</div></div>
              </div>)}
              {loading && <div className="message-row assistant"><div className="message-avatar"><Bot size={18}/></div><div className="message-body"><div className="message-name">JIGAR AI</div><div className="typing"><i/><i/><i/></div></div></div>}
              <div ref={endRef}/>
            </div>
          )}
        </section>

        <footer className="composer-wrap">
          <form className="composer" onSubmit={e => { e.preventDefault(); sendMessage() }}>
            <div className="composer-top"><span><Zap size={13}/> ASK ANYTHING</span><span>ENTER ↵</span></div>
            <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage() } }} placeholder="Message JIGAR AI..." rows={1}/>
            <div className="composer-bottom"><span className="composer-hint">Curiosity starts here. Shift + Enter for a new line.</span><button className="send-btn" type="submit" disabled={!input.trim() || loading}><Send size={17}/></button></div>
          </form>
          <p className="disclaimer">JIGAR AI can make mistakes. Verify important information.</p>
        </footer>
      </main>
    </div>
  )
}
